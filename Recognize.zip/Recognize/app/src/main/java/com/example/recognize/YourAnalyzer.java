package com.example.recognize;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;

public class YourAnalyzer implements ImageAnalysis.Analyzer{

    @Override
    public void analyze(@NonNull   ImageProxy image) {

    }
}
